﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace zeus_palace.Properties
{
    public partial class Room_Service : Form
    {
        public decimal sum = 0;
        public decimal v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13 = 1;
        public Room_Service()
        {
            InitializeComponent();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown5.Visible = checkBox5.Checked;
            if (checkBox5.Checked)
            {
                sum = sum + 8.9M * numericUpDown5.Value;
            }
            else
            {
                sum = sum - 8.9M * numericUpDown5.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown1.Visible = checkBox2.Checked;
            if (checkBox2.Checked)
            {
                sum = sum + 4.7M * numericUpDown1.Value;
            }
            else
            {
                sum = sum - 4.7M * numericUpDown1.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown2.Visible = checkBox1.Checked;
            if (checkBox1.Checked)
            {
                sum = sum + 8.9M * numericUpDown2.Value;
            }
            else
            {
                sum = sum - 8.9M * numericUpDown2.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown3.Visible = checkBox3.Checked;
            if (checkBox3.Checked)
            {
                sum = sum + 6.9M * numericUpDown3.Value;
            }
            else
            {
                sum = sum - 6.9M * numericUpDown3.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown4.Visible = checkBox4.Checked;
            if (checkBox4.Checked)
            {
                sum = sum + 5.7M * numericUpDown4.Value;
            }
            else
            {
                sum = sum - 5.7M * numericUpDown4.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown6.Visible = checkBox6.Checked;
            if (checkBox6.Checked)
            {
                sum = sum + 9.7M * numericUpDown6.Value;
            }
            else
            {
                sum = sum - 9.7M * numericUpDown6.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown7.Visible = checkBox7.Checked;
            if (checkBox7.Checked)
            {
                sum = sum + 9.7M * numericUpDown7.Value;
            }
            else
            {
                sum = sum - 9.7M * numericUpDown7.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown8.Visible = checkBox8.Checked;
            if (checkBox8.Checked)
            {
                sum = sum + 8.7M * numericUpDown8.Value;
            }
            else
            {
                sum = sum - 8.7M * numericUpDown8.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";


        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown9.Visible = checkBox9.Checked;
            if (checkBox9.Checked)
            {
                sum = sum + 7.8M * numericUpDown9.Value;
            }
            else
            {
                sum = sum - 7.8M * numericUpDown9.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown10.Visible = checkBox10.Checked;
            if (checkBox10.Checked)
            {
                sum = sum + 5 * numericUpDown10.Value;
            }
            else
            {
                sum = sum - 5 * numericUpDown10.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown11.Visible = checkBox11.Checked;
            if (checkBox11.Checked)
            {
                sum = sum + 9 * numericUpDown11.Value;
            }
            else
            {
                sum = sum - 9 * numericUpDown11.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown12.Visible = checkBox12.Checked;
            if (checkBox12.Checked)
            {
                sum = sum + 10 * numericUpDown12.Value;
            }
            else
            {
                sum = sum - 10 * numericUpDown12.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown13.Visible = checkBox13.Checked;
            if (checkBox13.Checked)
            {
                sum = sum + 12 * numericUpDown13.Value;
            }
            else
            {
                sum = sum - 12 * numericUpDown13.Value;
            }
            label4.Text = "Total Amount: " + sum + "€.";

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
                if (v1 < numericUpDown1.Value)
                {
                    sum = sum +4.7M ;
                } else if(v1> numericUpDown1.Value)
                {
                    sum = sum - 4.7M;
                }
                label4.Text = "Total Amount: " + sum + "€.";
                v1 = numericUpDown1.Value;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (sum > 0)
            {
                MessageBox.Show("Your Order Has Been Approved! \nIt Will Be Delivered To Your Room Soon! \n\n\nTotal Amount: " + sum + "€.\n*Τhe bill will be credited to your room account.");

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Rooms f =  new Rooms();
            f.Show();
            this.Close();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            if (v2 < numericUpDown2.Value)
            {
                sum = sum + 8.9M;
            }
            else if (v2 > numericUpDown2.Value)
            {
                sum = sum - 8.9M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v2 = numericUpDown2.Value;
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            if (v3 < numericUpDown3.Value)
            {
                sum = sum + 6.9M;
            }
            else if (v3 > numericUpDown3.Value)
            {
                sum = sum - 6.9M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v3 = numericUpDown3.Value;
        }

        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            if (v4 < numericUpDown4.Value)
            {
                sum = sum + 5.7M;
            }
            else if (v4 > numericUpDown4.Value)
            {
                sum = sum - 5.7M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v4 = numericUpDown4.Value;
        }

        private void numericUpDown5_ValueChanged(object sender, EventArgs e)
        {
            if (v5 < numericUpDown5.Value)
            {
                sum = sum + 8.9M;
            }
            else if (v5 > numericUpDown5.Value)
            {
                sum = sum - 8.9M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v5 = numericUpDown5.Value;
        }

        private void numericUpDown6_ValueChanged(object sender, EventArgs e)
        {
            if (v6 < numericUpDown6.Value)
            {
                sum = sum + 9.7M;
            }
            else if (v6 > numericUpDown6.Value)
            {
                sum = sum - 9.7M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v6 = numericUpDown6.Value;
        }

        private void numericUpDown7_ValueChanged(object sender, EventArgs e)
        {
            if (v7 < numericUpDown7.Value)
            {
                sum = sum + 9.7M;
            }
            else if (v7 > numericUpDown7.Value)
            {
                sum = sum - 9.7M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v7 = numericUpDown7.Value;
        }

        private void numericUpDown8_ValueChanged(object sender, EventArgs e)
        {
            if (v8 < numericUpDown8.Value)
            {
                sum = sum + 8.7M;
            }
            else if (v8 > numericUpDown8.Value)
            {
                sum = sum - 8.7M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v8 = numericUpDown8.Value;
        }

        private void numericUpDown9_ValueChanged(object sender, EventArgs e)
        {
            if (v9 < numericUpDown9.Value)
            {
                sum = sum + 7.8M;
            }
            else if (v9 > numericUpDown9.Value)
            {
                sum = sum - 7.8M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v9 = numericUpDown9.Value;
        }

        private void numericUpDown10_ValueChanged(object sender, EventArgs e)
        {
            if (v10 < numericUpDown10.Value)
            {
                sum = sum + 5M;
            }
            else if (v10 > numericUpDown10.Value)
            {
                sum = sum - 5M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v10 = numericUpDown10.Value;
        }

        private void numericUpDown11_ValueChanged(object sender, EventArgs e)
        {
            if (v11 < numericUpDown11.Value)
            {
                sum = sum + 9M;
            }
            else if (v11 > numericUpDown11.Value)
            {
                sum = sum - 9M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v11 = numericUpDown11.Value;
        }

        private void numericUpDown12_ValueChanged(object sender, EventArgs e)
        {
            if (v12 < numericUpDown12.Value)
            {
                sum = sum + 10M;
            }
            else if (v12 > numericUpDown12.Value)
            {
                sum = sum - 10M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v12 = numericUpDown12.Value;
        }

        private void numericUpDown13_ValueChanged(object sender, EventArgs e)
        {
            if (v13 < numericUpDown13.Value)
            {
                sum = sum + 12M;
            }
            else if (v13 > numericUpDown13.Value)
            {
                sum = sum - 12M;
            }
            label4.Text = "Total Amount: " + sum + "€.";
            v13 = numericUpDown13.Value;
        }
    }
}
