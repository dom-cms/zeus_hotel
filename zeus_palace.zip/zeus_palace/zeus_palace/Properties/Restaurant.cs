﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using zeus_palace.Properties;

namespace zeus_palace
{
    public partial class Restaurant : Form
    {
        public decimal sum = 0;
        public Restaurant()
        {
            InitializeComponent();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            label1.Text = "What Side To You Prefer?";
            timer2.Enabled = true;
            sum = sum + 20;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            label1.Text = "What Side To You Prefer?";
            timer2.Enabled = true;
            sum = sum = 20;
        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            button1.Visible = true;
            button2.Visible = true;
            button3.Visible = true;
            button4.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            label1.Text = "What Side To You Prefer?";
            timer2.Enabled = true;
            sum = sum + 15;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            label1.Text = "What Side To You Prefer?";
            timer2.Enabled = true;
            sum = sum + 15;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Enabled = false;
            button5.Visible = true;
            button6.Visible = true;
            button7.Visible = true;
            button8.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            label1.Text = "Would You Like To Drink Anything?";
            timer3.Enabled = true;
            sum = sum + 1;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            label1.Text = "Would You Like To Drink Anything?";
            timer3.Enabled = true;
            sum = sum + 5;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            label1.Text = "Would You Like To Drink Anything?";
            timer3.Enabled = true;
            sum = sum + 3.8M;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            label1.Text = "Would You Like To Drink Anything?";
            timer3.Enabled = true;
            sum = sum + 3.5M;
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Enabled = false;
            button9.Visible = true;
            button10.Visible = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button9.Visible = false;
            button10.Visible = false;
            label1.Text = "What Would You Like To Drink?";
            timer4.Enabled = true;
        }
        private void button10_Click(object sender, EventArgs e)
        {

            button9.Visible = false;
            button10.Visible = false;
            label1.Text = "Anything Else?";
            timer5.Enabled = true;
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            timer4.Enabled = false;
            button11.Visible = true;
            button12.Visible = true;
            button13.Visible = true;
            button14.Visible = true;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            label1.Text = "What Soft Drink Would You Like?";
            button15.Text = "Coca Cola";
            button16.Text = "Sprite";
            button17.Text = "Tonic";
            button18.Text = "Dr. Pepper";
            timer7.Enabled = true;
            sum = sum + 5;

        }

        private void button12_Click(object sender, EventArgs e)
        {
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            label1.Text = "What Beer Would You Like?";
            button15.Text = "Amstel";
            button16.Text = "Corona";
            button17.Text = "Kaisberg";
            button18.Text = "Murphy's";
            timer7.Enabled = true;
            sum = sum + 6;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            label1.Text = "Anything Else?";
            timer5.Enabled = true;
            sum = sum + 1;
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            timer7.Enabled = false;
            pictureBox2.Visible = false;
            label1.Visible = false;
            timer8.Enabled = true;
        }

        private void timer8_Tick(object sender, EventArgs e)
        {
            Point L;
            if (pictureBox1.Location.X < 1000)
            {
                L = new Point(pictureBox1.Location.X + 10, pictureBox1.Location.Y);
                pictureBox1.Location = L;
            }
            else
            {
                timer8.Enabled = false;
                button24.Visible = true;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            button14.Visible = false;
            label1.Text = "What Wine Would You Like?";
            button15.Text = "White Dry";
            button16.Text = "Red Dry";
            button17.Text = "White Sweet";
            button18.Text = "Red Sweet";
            timer7.Enabled = true;
            sum = sum + 8;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            button15.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            label1.Text = "Anything Else?";
            timer5.Enabled = true;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            button15.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            label1.Text = "Anything Else?";
            timer5.Enabled = true;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            button15.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            label1.Text = "Anything Else?";
            timer5.Enabled = true;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            button15.Visible = false;
            button16.Visible = false;
            button17.Visible = false;
            button18.Visible = false;
            label1.Text = "Anything Else?";
            timer5.Enabled = true;
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            timer5.Enabled = false;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            button19.Visible = false;
            button20.Visible = false;
            label1.Text = "What Today's Special Menu Would You Like To Try?";
            timer1.Enabled = true;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            button19.Visible = false;
            button20.Visible = false;
            label1.Text = "The Total Amount Is: " + sum + "€.\n How Would You Like To Pay?";
            timer6.Enabled = true;
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            timer6.Enabled = false;
            button21.Visible = true;
            button22.Visible = true;
            button23.Visible = true;
        }

        private void button21_Click(object sender, EventArgs e)
        {
            button21.Visible = false;
            button22.Visible = false;
            button23.Visible = false;
            label1.Text = "Thank You!\n We Hope To See You Again.";
            timer7.Enabled = true;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            button21.Visible = false;
            button22.Visible = false;
            button23.Visible = false;
            label1.Text = "Thank You!\n We Hope To See You Again.";
            timer7.Enabled = true;
            Payment f = new Payment();
            f.Show();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            button21.Visible = false;
            button22.Visible = false;
            button23.Visible = false;
            label1.Text = "Thank You!\nYour Room Account Has Been Charged.\n We Hope To See You Again.";
            timer7.Enabled = true;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }
    }
}
