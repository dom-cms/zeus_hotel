﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace zeus_palace.Properties
{
    public partial class Restaurant_Lobby : Form
    {
        public Restaurant_Lobby()
        {
            InitializeComponent();
        }

        private void Restaurant_Lobby_Load(object sender, EventArgs e)
        {
            timer1.Enabled= true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Point L;
            if (pictureBox1.Location.X > 500)
            {
                L = new Point(pictureBox1.Location.X - 10, pictureBox1.Location.Y);
                pictureBox1.Location = L;
            }
            else
            {
                timer1.Enabled = false;
                pictureBox2.Visible = true;
                label1.Visible = true;
                label1.BringToFront();
                timer2.Enabled = true;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            button1.Visible = true;
            button3.Visible = true;
            trackBar1.Visible = true;
            button6.Visible = true;
            button5.Visible = true;
            timer2.Enabled = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if(trackBar1.Value == 1) {
                button2.Visible = true;
                button4.Visible = true;
                button1.Visible = false;
                button3.Visible = false;
            } else
            {
                button2.Visible = false;
                button4.Visible = false;
                button1.Visible = true;
                button3.Visible = true;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Slide the trackbar: \nTo the left for brunch. \nTo the right for lunch and dinner.");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            JustCoffee f = new JustCoffee();
            f.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            JustDrinks f = new JustDrinks();
            f.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Brunch f = new Brunch();
            f.Show();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Restaurant f = new Restaurant();
            f.Show();
            this.Close();
        }
    }
}
