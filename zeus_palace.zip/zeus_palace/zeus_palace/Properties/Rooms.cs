﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace zeus_palace.Properties
{
    public partial class Rooms : Form
    {
        public Rooms()
        {
            InitializeComponent();
        }

        private void Rooms_Load(object sender, EventArgs e)
        {
           
        }

        private void Rooms_FormClosed(object sender, FormClosedEventArgs e)
        {
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please Enter Your Room Number!"); 
            } else
            {
                MessageBox.Show("Room Lights Turned ON!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please Enter Your Room Number!");
            }
            else
            {
                MessageBox.Show("Room Lights Turned OFF!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please Enter Your Room Number!");
            }
            else
            {
                MessageBox.Show("Room Temperature Set To: " + numericUpDown1.Value + " °C!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please Enter Your Room Number!");
            }
            else
            {
                var f = new Private_Pool();
                this.Close();
                f.ShowDialog();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please Enter Your Room Number!");
            }
            else
            {
                var f = new Appliances();
                this.Close();
                f.ShowDialog();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please Enter Your Room Number!");
            }
            else
            {
                var f = new Room_Service();
                this.Close();
                f.ShowDialog();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }
    }
}
