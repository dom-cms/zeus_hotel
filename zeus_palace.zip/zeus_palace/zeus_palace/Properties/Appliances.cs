﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace zeus_palace.Properties
{
    public partial class Appliances : Form
    {
        public Appliances()
        {
            InitializeComponent();
        }

        private void Appliances_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Room TV Turned ON!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Room TV Turned OFF!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Room Electric Fireplace Turned ON!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Room Electrtic Fireplace Turned OFF!");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Room Blinds Are Open!");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Room Blinds Aer Closed!");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Room Bluetooth Speakers Turned ON!");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Room Bluetooth Speakers Turned OFF!");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please Enter The Room Number You Want to Call!");
            }
            else
            {
                MessageBox.Show("Calling Room Nuber: " + textBox1.Text);
            }
        }

        private void Appliances_FormClosed(object sender, FormClosedEventArgs e)
        {
       
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Rooms f = new Rooms();
            f.Show();
            this.Close();
        }
    }
}
