﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace zeus_palace.Properties
{
    public partial class JustCoffee : Form
    {
        public decimal sum = 0;
        public JustCoffee()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            label1.Text = "Any Sugar?";
            timer2.Enabled = true;
            sum = sum + 4; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            label1.Text = "Any Sugar?";
            timer2.Enabled = true;
            sum = sum = 3.8M;
        }

        private void JustCoffee_Load(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            button1.Visible = true;
            button2.Visible = true;
            button3.Visible = true;
            button4.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            label1.Text = "Any Sugar?";
            timer2.Enabled = true;
            sum = sum + 3.8M;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            label1.Text = "Any Sugar?";
            timer2.Enabled = true;
            sum = sum + 4.2M;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Enabled = false;
            button5.Visible = true;
            button6.Visible = true;
            button7.Visible = true;
            button8.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            label1.Text = "Anything Else?";
            timer3.Enabled = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            label1.Text = "Anything Else?";
            timer3.Enabled = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            label1.Text = "Anything Else?";
            timer3.Enabled = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            label1.Text = "Anything Else?";
            timer3.Enabled = true;
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Enabled = false;
            button9.Visible = true;
            button10.Visible = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button9.Visible = false;
            button10.Visible = false;
            label1.Text = "What Coffee Should We Bring You?";
            timer1.Enabled = true;
        }

        private void button10_Click(object sender, EventArgs e)
        {

            button9.Visible = false;
            button10.Visible = false;
            label1.Text = "The Total Amount Is: " + sum + "€.\n How Would You Like To Pay?";
            timer4.Enabled = true;
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            timer4.Enabled = false;
            button11.Visible = true;
            button12.Visible = true;
            button13.Visible = true;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            label1.Text = "Thank You!\n We Hope To See You Again.";
            timer5.Enabled = true;

        }

        private void button12_Click(object sender, EventArgs e)
        {
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            label1.Text = "Thank You!\n We Hope To See You Again.";
            timer5.Enabled = true;
            Payment f = new Payment();
            f.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            button11.Visible = false;
            button12.Visible = false;
            button13.Visible = false;
            label1.Text = "Thank You!\nYour Room Account Has Been Charged.\n We Hope To See You Again.";
            timer5.Enabled = true;
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            timer5.Enabled = false;
            pictureBox2.Visible = false;
            label1.Visible = false;
            timer6.Enabled = true;
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            Point L;
            if (pictureBox1.Location.X < 1000)
            {
                L = new Point(pictureBox1.Location.X + 10, pictureBox1.Location.Y);
                pictureBox1.Location = L;
            }
            else
            {
                timer6.Enabled = false;
                button14.Visible = true;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }
    }
}
