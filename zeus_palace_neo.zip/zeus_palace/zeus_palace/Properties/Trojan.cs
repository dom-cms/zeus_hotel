﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace zeus_palace.Properties
{
    public partial class Trojan : Form
    {
        public Trojan()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (panel1.Visible)
            {
                panel1.Visible = false;
                button1.Text = "Show Horse Status";
            }  else {
                panel1.Visible = true; 
                button1.Text = "Hide Horse Status"; 
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Point L;
            L = new Point(pictureBox1.Location.X + 5, pictureBox1.Location.Y);
            pictureBox1.Location = L;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Point L;
            L = new Point(pictureBox1.Location.X , pictureBox1.Location.Y + 5);
            pictureBox1.Location = L;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Point L;
            L = new Point(pictureBox1.Location.X, pictureBox1.Location.Y - 5);
            pictureBox1.Location = L;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Point L;
            L = new Point(pictureBox1.Location.X - 5, pictureBox1.Location.Y);
            pictureBox1.Location = L;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Trojan Horse Doors Are Now Open!");
            label2.Text = "Doors: Open";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Trojan Horse Doors Are Now Closed!");
            label2.Text = "Doors: Closed";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Trojan Horse Doors Are Now Half Open!");
            label2.Text = "Doors: Half Open";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if(label3.Text == "Ladder: Up")
            {
                MessageBox.Show("Trojan Horse Ladder Is Now Down!");
                label3.Text = "Ladder: Down";
            } else if(label3.Text == "Ladder: Down" )
            {
                MessageBox.Show("Trojan Horse Ladder Is Now Up!");
                label3.Text = "Ladder: Up";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            button12.Visible = false;
            panel1.Visible = false;
            button1.Text = "Show Horse Status";
            label2.Text = "Doors: Closed";
            label3.Text = "Ladder: Up";
            button13.Visible = true;
            button14.Visible = true;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = true;
            button3.Visible = true;
            button4.Visible = true;
            button5.Visible = true;
            button6.Visible = true;
            button7.Visible = true;
            button8.Visible = true;
            button9.Visible = true;
            button10.Visible = true;
            button11.Visible = true;
            button12.Visible = true;
            button13.Visible = false;
            button14.Visible = false;
            this.BackgroundImage = Properties.Resources.zeusbackyard;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = true;
            button3.Visible = true;
            button4.Visible = true;
            button5.Visible = true;
            button6.Visible = true;
            button7.Visible = true;
            button8.Visible = true;
            button9.Visible = true;
            button10.Visible = true;
            button11.Visible = true;
            button12.Visible = true;
            button13.Visible = false;
            button14.Visible = false;
            this.BackgroundImage = Properties.Resources.olympiangarden;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (button11.Text == "Hide") {
                button1.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
                button4.Visible = false;
                button5.Visible = false;
                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;
                button10.Visible = false;
                button12.Visible = false;
                panel1.Visible = false;
                button11.Text = "Show";
            } else if(button11.Text == "Show") {
                button1.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button4.Visible = true;
                button5.Visible = true;
                button6.Visible = true;
                button7.Visible = true;
                button8.Visible = true;
                button9.Visible = true;
                button10.Visible = true;
                button12.Visible = true;
                panel1.Visible = true;
                button1.Text = "Show Horse Status";
                button11.Text = "Hide";
            }
            
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }
    }
}
