﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace zeus_palace.Properties
{
    public partial class Public_Pool : Form
    {
        public int T;
        public Public_Pool()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Water Level Changed To Level " + trackBar1.Value);
        }

        private void Private_Pool_Load(object sender, EventArgs e)
        {
            T = 20;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (T > 10)
            {
                T = T - 1;
                MessageBox.Show("Water Temperature Changed");
                label3.Text = "Current Water Temperature: " + T + "°C ";

            }
            else
            {
                MessageBox.Show("Minimium Temperature Reached!");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (T < 30)
            {
                T = T + 1;
                MessageBox.Show("Water Temperature Changed");
                label3.Text = "Current Water Temperature: " + T + "°C ";
            }
            else
            {
                MessageBox.Show("Maximum Temperature Reached!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Int16.Parse(textBox1.Text) >= 10 && Int16.Parse(textBox1.Text) <= 30)
            {
                T = Int16.Parse(textBox1.Text);
                MessageBox.Show("Water Temperature Changed");
                label3.Text = "Current Water Temperature: " + T + "°C ";
            }
            else
            {
                MessageBox.Show("Inappropriate Temperature!");
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label5.Visible = radioButton2.Checked;
            radioButton3.Visible = radioButton2.Checked;
            radioButton4.Visible = radioButton2.Checked;
            groupBox1.Visible = radioButton2.Checked;
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (radioButton2.Checked)
            {
                if (radioButton3.Checked)
                {
                    MessageBox.Show("Water Level: " + trackBar1.Value + ".\n Water Temperature: " + T + "°C.\n Sensor Enabled. There Is Someone In The Pool... Could It Be Poseidon? \n Alarm Enabled. \n Water Quality Olympian Perfect.", "Pool Status Results.");
                }
                else
                {
                    MessageBox.Show("Water Level: " + trackBar1.Value + ".\n Water Temperature: " + T + "°C.\n Sensor Enabled. There Is Someone In The Pool... Could It Be Poseidon? \n Alarm Disabled. \n Water Quality Olympian Perfect.", "Pool Status Results.");

                }
            }
            else
            {
                MessageBox.Show(" Water Level: " + trackBar1.Value + ".\n Water Temperature: " + T + "°C.\n Sensor Disabled. \n Water Quality Olympian Perfect.", "Pool Status Results.");

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Close();
        }
    }
}

